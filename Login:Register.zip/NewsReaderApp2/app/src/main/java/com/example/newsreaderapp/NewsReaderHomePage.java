package com.example.newsreaderapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NewsReaderHomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_reader_home_page);
    }
}